"use client";

import { useEffect, useState } from "react";
import { Controller, UseFormReturn } from "react-hook-form";

import PageHeader from "@/app/components/ui/navigation/PageHeader";
import { FormField } from "@/app/components/ui/form/FormField";
import { SelectInput } from "@/app/components/ui/form/SelectInput";
import { TextInput } from "@/app/components/ui/form/TextInput";
import { TextArea } from "@/app/components/ui/form/TextArea";

import {
  getEducationLevels,
  getGradeLevels,
  getPrograms,
  getSubjects,
  getTopics,
  getLessonTypes,
} from "@/app/helpers/lookups";

import { useCurriculumStore } from "@/app/store/useCurriculumStore";
import { AddLessonForm } from "../page";
import { getLessonBasicInfo } from "@/app/lib/lessonContent";

type Props = {
  form: UseFormReturn<AddLessonForm>;
  lessonId?: number | null;
  onNext: (lessonId: number) => void;
  setLessonId: (lessonId: number) => void;
  setBasicInfoSubmitted: (v: boolean) => void;
};

export default function BasicInformationStep({
  form,
  lessonId,
  setLessonId,
  onNext,
  setBasicInfoSubmitted,
}: Props) {
  const {
    register,
    control,
    watch,
    setValue,
    handleSubmit,
    formState: { errors, isSubmitting, isSubmitted },
  } = form;

  const activeCurriculum = useCurriculumStore(
    (state) => state.activeCurriculum
  );

  const { setActiveLesson } = useCurriculumStore();

  const [lesson, setLesson] = useState([]);
  const [lessonTypes, setLessonTypes] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [educationLevels, setEducationLevels] = useState<any[]>([]);
  const [gradeLevels, setGradeLevels] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [topics, setTopics] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [message, setMessage] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const educationLevelId = watch("educationLevelId");
  const gradeLevelId = watch("gradeLevelId");
  const subjectId = watch("subjectId");

  /* ---------------- LOAD EDIT DATA ---------------- */

  useEffect(() => {
    if (!lessonId) return;

    setLoading(true);
    getLessonBasicInfo(lessonId)
      .then((res) => {
        setLesson(res.data);
        form.setValue("name", res.data.name);
        form.setValue("description", res.data.description);
        form.setValue("lessonTypeId", res.data.lessonTypeId);
        form.setValue("programId", res.data.programId);
        form.setValue("educationLevelId", res.data.educationLevelId);
        form.setValue("gradeLevelId", res.data.gradeLevelId);
        form.setValue("subjectId", res.data.subjectId);
        form.setValue("topicId", res.data.topicId);
        form.setValue("start", res.data.start.slice(0, 16));
        form.setValue("end", res.data.end.slice(0, 16));
      })
      .finally(() => setLoading(false));
  }, [lessonId]);

  // useEffect(() => {
  //   if (lessonId !== null) {
  //     onNext(2);
  //   }
  // }, [lessonId]);

  /* ---------------- BASE LOOKUPS ---------------- */

  useEffect(() => {
    if (!activeCurriculum?.id) return;

    Promise.all([
      getLessonTypes(),
      getPrograms({ curriculumId: activeCurriculum.id }),
      getEducationLevels({ curriculumId: activeCurriculum.id }),
    ]).then(([lt, pr, el]) => {
      setLessonTypes(lt);
      setPrograms(pr);
      setEducationLevels(el);
    });
  }, [activeCurriculum]);

  /* ---------------- DEPENDENT LOOKUPS ---------------- */

  // Education → Grade
  useEffect(() => {
    if (!educationLevelId || !activeCurriculum?.id) {
      setGradeLevels([]);
      if (!isSubmitted) {
        setValue("gradeLevelId", null);
      }
      return;
    }

    getGradeLevels({
      curriculumId: activeCurriculum.id,
      educationLevelId,
    }).then(setGradeLevels);
  }, [educationLevelId, activeCurriculum, isSubmitted, setValue]);

  // Grade → Subject
  useEffect(() => {
    if (!gradeLevelId || !activeCurriculum?.id) {
      setSubjects([]);
      if (!isSubmitted) {
        setValue("subjectId", null);
      }
      return;
    }

    getSubjects({
      curriculumId: activeCurriculum.id,
      gradeLevelId,
    }).then(setSubjects);
  }, [gradeLevelId, activeCurriculum, isSubmitted, setValue]);

  // Subject → Topic
  useEffect(() => {
    if (!subjectId || !activeCurriculum?.id) {
      setTopics([]);
      if (!isSubmitted) {
        setValue("topicId", null);
      }
      return;
    }

    getTopics({
      curriculumId: activeCurriculum.id,
      subjectId,
    }).then(setTopics);
  }, [subjectId, activeCurriculum, isSubmitted, setValue]);

  /* ---------------- SUBMIT STEP ---------------- */

  const submitBasicInfo = async (data: AddLessonForm) => {
    const res = await fetch("/api/lesson", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        lessonId: lessonId || null,
        lessonTypeId: data.lessonTypeId,
        curriculumId: activeCurriculum?.id,
        subjectId: data.subjectId,
        gradeLevelId: data.gradeLevelId,
        educationLevelId: data.educationLevelId,
        topicId: data.topicId,
        programId: data.programId,
        name: data.name,
        description: data.description,
        start: data.start,
        end: data.end,
      }),
    });

    const result = await res.json();

    setMessage(result?.message);

    const lessonId_new = result?.data?.id;

    if (!lessonId_new) {
      console.error("Lesson ID not returned from server");
      return;
    }
    setActiveLesson(result?.data);

    setLessonId(lessonId_new);
    setBasicInfoSubmitted(true);

    // onNext(2);
  };

  /* ---------------- UI ---------------- */

  return (
    <>
      <PageHeader
        title="Basic Information"
        description="Add basic information about your lesson"
      />
      {message}

      <form
        onSubmit={handleSubmit(submitBasicInfo)}
        className="grid grid-cols-2 gap-4 p-8"
      >
        <FormField label="Lesson Name" error={errors.name?.message}>
          <TextInput
            placeholder="Enter Lesson name"
            {...register("name", { required: "Lesson name is required" })}
          />
        </FormField>

        <FormField label="Lesson Type" error={errors.lessonTypeId?.message}>
          <Controller
            name="lessonTypeId"
            control={control}
            rules={{ required: "Lesson type is required" }}
            render={({ field }) => (
              <SelectInput
                value={field.value?.toString()}
                options={lessonTypes.map((l) => ({
                  label: l.name,
                  value: l.id.toString(),
                }))}
                onChange={(v) => field.onChange(Number(v))}
                placeholder="Select lesson type"
              />
            )}
          />
        </FormField>

        <div className="col-span-2">
          <FormField
            label="Lesson Description"
            error={errors.description?.message}
          >
            <Controller
              name="description"
              control={control}
              rules={{ required: "Description is required" }}
              render={({ field }) => (
                <TextArea
                  value={field.value}
                  onChange={field.onChange}
                  placeholder="Enter lesson description..."
                />
              )}
            />
          </FormField>
        </div>

        <FormField label="Program" error={errors.programId?.message}>
          <Controller
            name="programId"
            control={control}
            rules={{ required: "Program is required" }}
            render={({ field }) => (
              <SelectInput
                value={field.value?.toString()}
                options={programs.map((p) => ({
                  label: p.name,
                  value: p.id.toString(),
                }))}
                onChange={(v) => field.onChange(Number(v))}
              />
            )}
          />
        </FormField>

        <FormField
          label="Education Level"
          error={errors.educationLevelId?.message}
        >
          <Controller
            name="educationLevelId"
            control={control}
            rules={{ required: "Education Level is required" }}
            render={({ field }) => (
              <SelectInput
                value={field.value?.toString()}
                options={educationLevels.map((e) => ({
                  label: e.name,
                  value: e.id.toString(),
                }))}
                onChange={(v) => field.onChange(Number(v))}
              />
            )}
          />
        </FormField>

        <FormField label="Grade Level" error={errors.gradeLevelId?.message}>
          <Controller
            name="gradeLevelId"
            control={control}
            rules={{ required: "Grade Level is required" }}
            render={({ field }) => (
              <SelectInput
                value={field.value?.toString()}
                options={gradeLevels.map((g) => ({
                  label: g.name,
                  value: g.id.toString(),
                }))}
                onChange={(v) => field.onChange(Number(v))}
              />
            )}
          />
        </FormField>

        <FormField label="Subject" error={errors.subjectId?.message}>
          <Controller
            name="subjectId"
            control={control}
            rules={{ required: "Subject is required" }}
            render={({ field }) => (
              <SelectInput
                value={field.value?.toString()}
                options={subjects.map((s) => ({
                  label: s.name,
                  value: s.id.toString(),
                }))}
                onChange={(v) => field.onChange(Number(v))}
              />
            )}
          />
        </FormField>

        <div className="col-span-2">
          <FormField label="Topic" error={errors.topicId?.message}>
            <Controller
              name="topicId"
              control={control}
              rules={{ required: "Topic is required" }}
              render={({ field }) => (
                <SelectInput
                  value={field.value?.toString()}
                  options={topics.map((t) => ({
                    label: t.name,
                    value: t.id.toString(),
                  }))}
                  onChange={(v) => field.onChange(Number(v))}
                />
              )}
            />
          </FormField>
        </div>

        <FormField label="Start Time" error={errors.start?.message}>
          <TextInput
            type="datetime-local"
            {...register("start", { required: "Start time is required" })}
          />
        </FormField>

        <FormField label="End Time" error={errors.end?.message}>
          <TextInput
            type="datetime-local"
            {...register("end", { required: "End time is required" })}
          />
        </FormField>

        <div className="col-span-2">
          <div className="flex justify-end pt-4">
            <button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-600 text-white px-6 py-2 rounded-md font-medium"
            >
              {isSubmitting ? "Saving..." : "Next"}
            </button>
          </div>
        </div>
      </form>
    </>
  );
}
